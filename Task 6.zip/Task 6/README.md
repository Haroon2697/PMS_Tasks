# Task 6 — Cost Optimization Submission Package

This folder contains the complete submission package for **Task 6: Cost Optimization of Modelled Enterprise System**.

---

## 📁 Package Contents

```
Task 6/
├── README.md                              # This overview and contents guide
├── TASK_6_COST_OPTIMIZATION_REPORT.md     # Comprehensive academic & technical submission report
└── Task_6_Source_Files/                   # Specific source code and test files for Task 6
    ├── engine/
    │   ├── cost/costEngine.ts             # 9-line additive cost engine, BOM explosion, additivity verification
    │   ├── finance/investment.ts          # ROI, simple & discounted payback, NPV, annualization
    │   ├── optimize/scenarios.ts          # Scenario comparison, parameter modifications, Welch t-test
    │   ├── optimize/optimizer.ts          # Automated heuristic configuration optimizer
    │   ├── model/referenceModel.ts        # Baseline automotive assembly line definition
    │   ├── model/types.ts                 # Cost types, parameter provenance contracts
    │   ├── model/defaults.ts              # Default wage classes, machine attributes, BOM values
    │   ├── validation/validate.ts         # Parameter validation & provenance census
    │   └── tests/cost.test.ts             # 75 unit & integration tests for cost and optimization
    └── web/pages/
        ├── Cost.tsx                       # Manufacturing cost breakdown & additivity proof UI
        ├── VehicleCost.tsx                # Vehicle BOM & individual trace costing UI
        ├── Financial.tsx                  # Financial statements, cash flow, ROI/payback UI
        ├── Scenarios.tsx                  # Scenario comparison manager UI
        └── Optimization.tsx               # Automated cost optimizer UI
```

---

## 🔬 Key Task 6 Highlights

1. **Strict Accounting Partition**: The nine additive cost categories partition total manufacturing cost with mathematical proof of zero double-counting (`|sum - total| = 0.00000000`).
2. **Transparent Cost Assumptions**: All cost inputs carry provenance labels (`PROJECT ASSUMPTION` vs `SOURCE-BACKED`).
3. **Trace-Level Costing**: Selecting individual vehicles demonstrates the exact cost penalty of rework ($V-55: $14,212.58 vs $V-56: $15,207.80, a +$995.22 penalty).
4. **End-to-End Optimization**: Resolving the Paint Shop bottleneck via a 4th booth reduces queue wait by 25.5% ($p < 0.001$). Under elevated demand (+25%), the investment delivers a **14.91% ROI** and a **6.71-year payback**.
5. **Automated Verification**: Backed by **75 passing tests** in `tests/cost.test.ts`.

For full analytical formulas, tables, proofs, and demonstration steps, see [TASK_6_COST_OPTIMIZATION_REPORT.md](TASK_6_COST_OPTIMIZATION_REPORT.md).
