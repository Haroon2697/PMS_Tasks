# Task 6 — Cost Optimization of Modelled Enterprise System

**Course Module**: Enterprise Systems Modelling & Performance Analysis  
**Assignment**: Task 6 — Cost Optimization  
**Instructor**: Naveed Ahmad  
**Status**: Completed & Fully Verified (75 Dedicated Cost Tests Passing, 228 Engine Tests Total)

---

## 1. Executive Summary

This report demonstrates the **cost optimization** of an automotive manufacturing enterprise system. The modelled system represents a full-scale automotive assembly line consisting of 10 sequential and feedback workcentres (Parts Receiving, Body Manufacturing, Body Shop, Paint Shop, Powertrain Installation, Interior Installation, Electrical Installation, Final Assembly, Quality Inspection, and Rework).

The core objectives fulfilled in this submission are:
1. **Comprehensive Cost Accounting Model**: Ten distinct cost categories are rigorously modelled. The nine additive categories form a strict **partition** of total manufacturing cost with mathematical additivity verification (discrepancy $= 0.00000000$).
2. **Provenance-Tracked Cost Assumptions**: All cost parameters (unit costs, labor rates, power consumptions, machine depreciation, scrap allowances, overhead allocations) are explicitly categorized with provenance labels (`PROJECT ASSUMPTION` vs `SOURCE-BACKED`) and are completely configurable.
3. **Trace-Level Per-Vehicle Costing**: Individual vehicles track their exact realization through the plant, showing precise cost divergence between first-pass vehicles and reworked vehicles.
4. **End-to-End Cost Optimization**: Bottleneck identification (Paint Shop) followed by investment appraisal (adding a 4th paint booth). Both baseline and optimized configurations are fully re-simulated across multiple stochastic replications with Welch's t-test statistical significance, annual net benefit, ROI, and payback period calculations under varying demand conditions.

---

## 2. Modelled Enterprise System Architecture

The enterprise system models a high-volume passenger vehicle assembly facility operating on a 250-day/year, 8-hour/day production schedule (2,000 operational hours/year).

```
[Vehicle Arrival: λ = 5.6 veh/h]
       │
       ▼
[Parts Receiving] (c=2, μ=8.2 min)
       │
       ▼
[Body Manufacturing] (c=3, μ=20.8 min)
       │
       ▼
[Body Shop] (c=3, μ=25.1 min)
       │
       ▼
[Paint Shop] (c=3, μ=28.0 min) ◄── [IDENTIFIED BOTTLENECK: ρ = 87.1% - 99.6%]
       │
       ▼
[Powertrain Installation] (c=3, μ=23.7 min)
       │
       ▼
[Interior Installation] (c=3, μ=19.7 min)
       │
       ▼
[Electrical Installation] (c=2, μ=15.1 min)
       │
       ▼
[Final Assembly] (c=4, μ=29.6 min, Erlang-2)
       │
       ▼
[Quality Inspection] (c=2, μ=10.7 min) ───[Defect: 10% - 12.4%]───► [Rework] (c=1, μ=48.3 min)
       │                                                                  │
       ├──────────────────────────────────────────────────────────────────┘
       ▼
[Finished Vehicle Dispatch] (Selling Price: $22,500)
```

---

## 3. The Cost Accounting Model

Cost is not simplified to flat labor hours or generic overhead. Ten distinct cost categories are modelled dynamically based on operational state and actual resource utilization.

### 3.1 The Ten Cost Categories

1. **Direct Material**: Computed from a 20-component Bill of Materials (BOM) attributed along each vehicle's actual path:
   $$\text{Line Cost} = \text{Quantity} \times (1 + \text{Scrap Allowance}) \times \text{Unit Cost}$$
   Baseline material cost per vehicle is **$12,703.86**.
2. **Direct Labour**: Headcount $\times$ wage $\times$ operating hours across 5 skill classes (General Assembly, Skilled Painter, Powertrain Specialist, Electrical Technician, Quality Inspector), accounting for shift premiums and overtime multipliers.
3. **Machine Cost**: Straight-line asset depreciation plus operating consumables:
   $$\text{Depreciation Rate (\$/h)} = \frac{\text{Purchase Price} - \text{Salvage Value}}{\text{Useful Life (years)} \times \text{Annual Operating Hours (2,000 h)}}$$
4. **Energy**: Real-time electrical power consumption:
   $$\text{Energy Cost} = \text{Power (kW)} \times \text{Operating Time (hours)} \times \text{Electricity Tariff (\$/kWh)}$$
   Distinguishes between active processing power and idle standby power.
5. **Maintenance**: Scheduled preventive maintenance plus corrective breakdown maintenance tied to machine reliability (MTBF/MTTR).
6. **Quality / Inspection**: Dedicated inspection labor and specialized quality test consumables.
7. **Rework**: Costs incurred exclusively during defect remediation (rework kit consumables and repair bay labor).
8. **Scrap (Material Written Off)**: Unrecoverable direct materials discarded during inspection failures.
9. **Allocated Overhead**: Plant facility rent, administrative management, software systems, and building utilities amortized across production volume.
10. **Waiting / WIP & Destroyed Value (Reported Separately)**:
    - *Queue Waiting Cost*: Opportunity cost of working capital tied up in buffers ($\$15,102.95$ per 40 h). Kept outside total manufacturing cost because it is not cash paid to assemble the car.
    - *Total Destroyed Value*: Full loss of scrapped units (materials + labor + machine hours spent prior to rejection = $\$68,445.78$).

### 3.2 Additivity Verification (Zero Double-Counting)

A fundamental principle of our cost engine is **accounting partition**:
- An inspector's wages appear in *Quality*, never in both *Labour* and *Quality*.
- Rework kit materials appear in *Rework*, never in *Direct Material*.
- Total manufacturing cost is the exact sum of the nine additive lines.

The engine verifies this on every run via `verifyAdditivity()`:
$$\left| \sum_{i=1}^{9} \text{Line}_i - \text{Reported Total} \right| = 0.00000000$$

### 3.3 Baseline Cost Structure (40-Hour Measurement Window, 212 Vehicles)

| Cost Category | Total Cost ($) | Cost Per Vehicle ($) | Percentage Share | Accounting Treatment |
|---|---:|---:|---:|---|
| **Direct Material** | 2,693,218.32 | 12,703.86 | 85.5% | Additive (BOM) |
| **Direct Labour** | 100,800.00 | 475.47 | 3.2% | Additive (Headcount $\times$ Wage) |
| **Machine Running** | 42,090.05 | 198.54 | 1.3% | Additive (Depreciation + Consumables) |
| **Energy** | 11,708.62 | 55.23 | 0.4% | Additive (Active + Idle kWh) |
| **Maintenance** | 28,480.01 | 134.34 | 0.9% | Additive (Preventive + Corrective) |
| **Quality / Inspection** | 8,565.56 | 40.40 | 0.3% | Additive (Inspector Labor + Testing) |
| **Rework** | 9,793.15 | 46.19 | 0.3% | Additive (Rework Bay + Materials) |
| **Scrap Written Off** | 63,519.30 | 299.62 | 2.0% | Additive (Material Loss) |
| **Allocated Overhead** | 192,000.00 | 905.66 | 6.1% | Additive (Facility Amortization) |
| **TOTAL MANUFACTURING COST** | **$3,150,175.01** | **$14,859.32** | **100.0%** | **Additive Partition** |
| *WIP Queue Waiting (Opportunity)* | *15,102.95* | *71.24* | *—* | *Reported Separately (Outside Total)* |
| *Total Scrap Value Destroyed* | *68,445.78* | *322.86* | *—* | *Reported Separately (Outside Total)* |

---

## 4. Provenance of Cost Assumptions

As required by the assignment prompt ("*Cost assumptions are important*"), every single cost assumption is catalogued with its provenance, units, and validation status:

| Parameter | Baseline Value | Units | Provenance Category | Notes / Basis |
|---|---:|:---:|:---:|---|
| **Electricity Price** | 0.085 | $/kWh | `PROJECT ASSUMPTION` | Industrial off-peak composite tariff |
| **General Assembly Wage** | 28.00 | $/h | `PROJECT ASSUMPTION` | Level 1 manufacturing technician |
| **Specialist Labor Wage** | 36.00 | $/h | `PROJECT ASSUMPTION` | Paint & powertrain certified technicians |
| **Inspection Labor Wage** | 34.00 | $/h | `PROJECT ASSUMPTION` | Quality assurance certified inspector |
| **Steel Body Sheet (BOM)** | 1.10 | $/kg | `PROJECT ASSUMPTION` | Stamped galvanized automotive sheet |
| **Engine Assembly (BOM)** | 3,200.00 | $/unit | `PROJECT ASSUMPTION` | 2.0L Turbocharged powertrain module |
| **Transmission (BOM)** | 1,450.00 | $/unit | `PROJECT ASSUMPTION` | 8-speed automatic transaxle |
| **Paint Materials (BOM)** | 220.00 | $/veh | `PROJECT ASSUMPTION` | E-coat primer, basecoat, clearcoat |
| **Paint Booth Capital** | 2,400,000.00 | $ | `PROJECT ASSUMPTION` | Automated robotic spray enclosure |
| **Paint Booth Life** | 12.0 | years | `PROJECT ASSUMPTION` | Straight-line asset life |
| **Paint Booth Power** | 45.0 | kW | `PROJECT ASSUMPTION` | HVAC + downdraft filtration motors |
| **Vehicle Selling Price** | 22,500.00 | $/veh | `PROJECT ASSUMPTION` | Wholesale invoice realization |
| **Factory Operating Hours** | 2,000.0 | h/year | `PROJECT ASSUMPTION` | 250 days $\times$ 8 hours/day |
| **Annual Fixed Overhead** | 9,600,000.00 | $/year | `PROJECT ASSUMPTION` | Facility rent, depreciation, SG&A |

Every assumption is editable in the UI (`System Configuration` & `Model Validation`). Modifying any parameter instantly recalculates all downstream costs and flags modified items.

---

## 5. Vehicle Trace-Level Cost Discrepancy

Costing is tied to discrete vehicle entities rather than gross factory averages. This demonstrates the actual financial penalty of rework loops:

### First-Pass Vehicle (V-55) vs Reworked Vehicle (V-56)

```
Vehicle V-55 (Passed Inspection First Time):
  Total Lead Time: 180.8 minutes (3.01 hours)
  Direct Material: $12,703.86
  Direct Labour:      $412.18
  Machine & Energy:   $235.14
  Maintenance:        $112.50
  Quality/Inspection:  $38.40
  Rework:               $0.00
  Overhead:           $710.50
  TOTAL COST:      $14,212.58

Vehicle V-56 (Failed Inspection, Sent to Rework, Re-inspected):
  Total Lead Time: 357.6 minutes (5.96 hours)  [+97.8% duration]
  Direct Material: $12,703.86
  Direct Labour:      $642.45                  [+$230.27]
  Machine & Energy:   $357.49                  [+$122.35]
  Maintenance:        $221.94                  [+$109.44]
  Quality/Inspection:  $78.20                  [+$39.80 - two inspection cycles]
  Rework Kit & Bay:   $533.15                  [+$533.15]
  Overhead:           $670.71                  [-$39.79]
  TOTAL COST:      $15,207.80                  [+$995.22 cost penalty]
```

**Key Takeaway**: A vehicle that experiences quality failure and rework costs **$995.22 more** and occupies factory buffers for nearly double the time.

---

## 6. Cost Optimization Demonstration

### 6.1 Bottleneck Identification
Analytical evaluation and DES simulation identify **Paint Shop** as the enterprise bottleneck:
- Number of servers: $c = 3$
- Mean service time: $\mu = 28.0$ minutes
- Station capacity: $\frac{3 \times 60}{28.0} = 6.429$ vehicles/hour
- Baseline arrival rate: $\lambda = 5.600$ vehicles/hour
- Server utilisation: $\rho = \frac{5.600}{6.429} = 87.1\%$ (peaking at $99.6\%$ during demand surges)
- Mean queue waiting time: $W_q = 111.1$ minutes (accounts for 72% of total plant waiting time)

### 6.2 Optimization Proposal: 4th Paint Booth Addition
We formulate an optimization intervention:
- **Capital Investment**: $\$2,400,000$ (purchase + installation)
- **Useful Life**: 12 years (Salvage: $\$240,000$)
- **Additional Annual Operating Cost**: $\$180,000$/year (operators, power, preventive servicing)
- **New Station Capacity**: $c = 4 \implies \frac{4 \times 60}{28.0} = 8.571$ vehicles/hour
- **Factory Capacity**: Increases from $6.429$ to $7.200$ veh/h (shifting plant bottleneck to Powertrain Installation)

### 6.3 Simulation Results & Welch's t-Test Significance (10 Replications)

Both configurations were fully re-simulated across 10 independent replications (40-hour window each). Welch's two-sample t-test determines whether observed improvements are statistically significant:

| Performance Metric | Current Baseline (3 Booths) | Optimized (4 Booths) | Absolute Change | Relative Change | Statistically Significant? |
|---|---:|---:|---:|---:|:---:|
| **Throughput** (veh/h) | 5.365 | 5.365 | 0.000 | 0.0% | No ($p > 0.05$) |
| **Manufacturing Lead Time $W$** (min) | 302.4 | 273.8 | **-28.6** | **-9.5%** | **YES ($p < 0.001$)** |
| **Queue Waiting Time $W_q$** (min) | 111.1 | 82.7 | **-28.3** | **-25.5%** | **YES ($p < 0.001$)** |
| **WIP Queue Length $L_q$** (vehicles) | 9.87 | 7.49 | **-2.38** | **-24.1%** | **YES ($p < 0.001$)** |
| **Unit Cost per Vehicle** ($) | $14,830.84 | $14,841.99 | +$11.15 | +0.08% | No ($p = 0.28$) |
| **Plant Capacity** (veh/h) | 6.429 | 7.200 | +0.771 | +12.0% | Model Property |
| **System Bottleneck** | Paint Shop | Powertrain Inst. | — | Shifted | System Property |

---

## 7. Financial Appraisal: ROI, Payback, and Demand Sensitivity

The economic viability of the optimization depends critically on market demand:

$$\text{Revenue} = \text{Completed Vehicles} \times \text{Selling Price (\$22,500)}$$
$$\text{Profit} = \text{Revenue} - \text{Total Cost}$$
$$\text{Annual Net Benefit} = \Delta\text{Annual Operating Profit} - \text{Additional Annual Opex}$$
$$\text{Simple Payback Period} = \frac{\text{Initial Capital Investment (\$2,400,000)}}{\text{Annual Net Benefit}}$$

### Comparative Financial Appraisal Matrix

| Scenario / Decision Parameter | Case A: Current Demand ($\lambda = 5.6$ veh/h) | Case B: High Demand (+25% $\implies \lambda = 7.0$ veh/h) |
|---|---:|---:|
| **Initial Capital Investment** | $2,400,000 | $2,400,000 |
| **Additional Annual Operating Cost** | $180,000 | $180,000 |
| **System Stability Without 4th Booth** | Stable ($\lambda < \text{Cap}: 5.6 < 6.43$) | **UNSTABLE ($\lambda > \text{Cap}: 7.0 > 6.43 \implies \rho = 108.9\%$)** |
| **Throughput Improvement** | 0.000 veh/h (Demand-limited) | **+1.583 veh/h (+3,166 vehicles/year)** |
| **Waiting Time Reduction $\Delta W_q$** | -28.3 min (-25.5%) | **-104.9 min (-29.7%)** |
| **Annual Net Benefit** | **-$83,330** | **+$357,882** |
| **Return on Investment (ROI)** | **-3.47%** | **+14.91% / year** |
| **Payback Period** | **NOT ACHIEVED** | **6.71 Years (80.5 Months)** |

### Critical Economic Insight Demonstrated
1. **At Current Demand ($\lambda = 5.6$ veh/h)**: The factory already satisfies customer demand with 3 booths. Adding a 4th booth buys **shorter queues and reduced lead time, but zero extra vehicle sales**. Because revenue does not increase, the additional operating cost produces a negative net benefit (-$83,330/yr). The system correctly reports **Payback: NOT ACHIEVED** rather than fabricating an artificial payback.
2. **At High Demand ($\lambda = 7.0$ veh/h)**: Without the 4th booth, the line is unstable ($\rho > 1$), queues grow infinitely, and customer orders are lost. With the 4th booth, the line delivers 3,166 additional vehicles annually, yielding **+$357,882 annual net benefit**, an **ROI of 14.91%**, and full capital payback in **6.71 years**.

---

## 8. Verification and Automated Testing

The cost optimization engine is backed by **75 unit and integration tests** in `tests/cost.test.ts`:
- `expandBom()` verifies unit prices, quantities, and scrap multipliers across all 20 BOM lines.
- `verifyAdditivity()` asserts that the nine additive lines partition the total with zero double counting.
- `machineDepreciationPerHour()` verifies straight-line depreciation against useful life and operating hours.
- `energyCost()` tests linear scaling against electricity tariffs.
- `compareScenarios()` verifies Welch t-test p-values, degrees of freedom, and significance flags.
- `optimize()` verifies that the automated optimizer identifies feasible configurations meeting throughput constraints.
- `paybackPeriod()` verifies that investments with non-positive net benefits return `null` ("Not achieved").

All 75 tests pass with 100% success rate.

---

## 9. How to Demonstrate in the Application

1. **Verify Unit & Per-Vehicle Cost**:
   - Navigate to **Economics $\rightarrow$ Manufacturing Cost**: Review the 9 additive cost lines and check the **Additivity Proof** card showing $0.00000000$ discrepancy.
   - Navigate to **Economics $\rightarrow$ Vehicle Cost / BOM**: Inspect the 20-component BOM.
   - Navigate to **Operations $\rightarrow$ Live Factory**: Click on any completed vehicle in the simulation (e.g. V-55 vs V-56) to see the individual cost breakdown.
2. **Demonstrate Cost Optimization Comparison**:
   - Navigate to **Decisions $\rightarrow$ Scenario Manager**.
   - Create a scenario: Select "Add server" $\rightarrow$ "Paint Shop" $\rightarrow$ Servers: 4, Capital Cost: $2,400,000.
   - Click **Compare Scenarios**: Review the side-by-side table displaying throughput, $W$, $W_q$, $L_q$, cost/vehicle, and the Welch t-test significance column.
   - Review the financial appraisal card showing Payback: "Not Achieved" under baseline demand.
3. **Flip the Payback Verdict (Demand Shock)**:
   - Navigate to **Model $\rightarrow$ System Configuration $\rightarrow$ Demand Schedule**.
   - Increase arrival rate $\lambda$ from 5.6 to 7.0 veh/h.
   - Return to **Scenario Manager** and re-run comparison: Observe the financial appraisal flip to **ROI: 14.91%** and **Payback: 6.71 years**.
