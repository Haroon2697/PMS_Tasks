# Task 7 — Process Discovery through Event Traces Submission Package

This folder contains the complete submission package for **Task 7: Process Discovery through Event Traces & Queueing Simulation**.

---

## 📁 Package Contents

```
Task 7/
├── README.md                              # This overview and contents guide
├── TASK_7_PROCESS_DISCOVERY_REPORT.md     # Comprehensive academic & technical submission report
├── sample_event_logs/                     # Ready-to-use event trace datasets (CSV)
│   ├── automotive_manufacturing_traces.csv # 2,010 rows, 217 vehicles, full assembly line traces
│   └── sample_traces_with_rework.csv      # Compact demonstration trace showing normal & rework flow
└── Task_7_Source_Files/                   # Specific source code and test files for Task 7
    ├── engine/
    │   ├── discovery/
    │   │   ├── eventLog.ts                # Robust CSV parser, synonym resolution, timestamp unwrap
    │   │   ├── discover.ts                # Directly-follows graph, loop mining, CV distribution fitting
    │   │   ├── toModel.ts                 # Graph-to-queue-model conversion & 3-way triangulation
    │   │   └── fromSimulation.ts          # Simulation trace to CSV event log exporter
    │   ├── des/
    │   │   ├── simulation.ts              # Discrete-event simulation engine
    │   │   ├── eventQueue.ts              # Binary min-heap event calendar
    │   │   └── vehicle.ts                 # Vehicle entity lifecycle & visit traces
    │   ├── analytical/
    │   │   ├── queues.ts                  # Erlang C, M/M/c, M/Ek/c queueing formulas
    │   │   └── traffic.ts                 # Traffic equations for cyclic routing
    │   └── tests/discovery.test.ts        # 62 unit & round-trip verification tests
    └── web/pages/
        ├── EventLog.tsx                   # Event log ingestion, drag-and-drop, validation UI
        ├── Discovery.tsx                  # Process discovery graph & assumptions UI
        └── DiscoveredModel.tsx            # Discovered queue model, 3-way table, live simulation UI
```

---

## 🔬 Key Task 7 Highlights

1. **End-to-End Pipeline**: From raw CSV event logs to directly-follows graphs, queue model estimation, Erlang C analytical solutions, and discrete-event simulation.
2. **Automated Feedback Loop Detection**: Automatically mines rework loops (`Quality Inspection ⇄ Rework` at 11.43% defect rate, 1.129 visits per case).
3. **Principled Distribution & Server Fitting**: Fits distribution families using the Coefficient of Variation ($CV < 1 \implies \text{Erlang-}k, CV \approx 1 \implies M$) and estimates server capacity via maximum observed concurrency lower bounds.
4. **Three-Way Triangulation**: Direct comparison between Observed (log data), Analytical (Erlang C steady state), and Simulated (discrete-event simulation) performance.
5. **Round-Trip Validation**: Verified by generating traces from a known reference line and proving that discovery recovers the original topology, rates, distributions, and server counts.
6. **Automated Verification**: Backed by **62 passing tests** in `tests/discovery.test.ts`.

For full equations, discovery tables, and round-trip verification, see [TASK_7_PROCESS_DISCOVERY_REPORT.md](TASK_7_PROCESS_DISCOVERY_REPORT.md).
